# Camera Targeting Test Script

You can use this to test your cameras one at a time.

Be sure to set line 7 to your camera address.

